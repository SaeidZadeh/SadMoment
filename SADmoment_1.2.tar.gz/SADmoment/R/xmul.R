xmul <-
function(u)
{
	u[2,]<-u[2,]+1
	return(u)
}
