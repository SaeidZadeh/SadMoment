cmoment <-
function(mu,sig,k)
{
	return(mu^k+smom(mu,sig,k))
}
