fprime <-
function(a, n, s)
{
	return(log(1+(n/a))-(n/(a+n)))
}
