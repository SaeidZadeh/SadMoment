fo <-
function(a, n, s)
{
	return(a*log(1+(n/a))-s)
}
