mo2nd <-
function(res,slope,A)
{
	return(exp(slope*log(A)+res));
}
