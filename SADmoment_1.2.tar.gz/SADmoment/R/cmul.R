cmul <-
function(u,c)
{
	u[1,]<-u[1,]*c;
	return(u)
}
