numsum <-
function(n,x,k)
{
	s<-k^n*ptransform(x,k);
	return(s);
}
