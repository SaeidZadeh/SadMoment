mufinderLN <-
function(res,slope,A)
{
	return(log(2)*exp(slope*log(A)+res));
}
